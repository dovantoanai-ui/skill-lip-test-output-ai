# 4-vai-khach-nemthanh.md

Mô tả chi tiết 4 vai khách cho Cách 1 (Đóng vai). Đọc lazy — chỉ load khi chạy Cách 1.

Persona Vai Mục tiêu lift từ skill `thuong-hieu-content` (5 persona Vịt Cổ Lũng đã có sẵn) — không duplicate, chỉ tham chiếu.

---

## 🎯 Vai 1 — KHÁCH MỤC TIÊU (×2 trọng số)

Chọn 1 trong 5 persona Vịt Cổ Lũng tùy nội dung output:

### Persona A — Bà nội trợ Hà Nội 35-50 tuổi (cho content nem chua / Vịt Cổ Lũng)
- **Tâm lý:** quan tâm sức khỏe gia đình, hay đọc Facebook nhóm "Mẹ và bé"
- **Pain:** sợ thực phẩm bẩn, sợ hóa chất, hay so giá
- **Tech:** dùng iPhone, Facebook, Zalo OA — KHÔNG Twitter/LinkedIn
- **Behavior:** đọc post 30 giây, scroll nếu không có hook
- **Dealbreaker:** thiếu giấy chứng nhận / thiếu nguồn gốc / quá quảng cáo

### Persona B — CEO/Manager nam 30-45 tuổi (cho personal brand Toàn)
- **Tâm lý:** trân trọng giá trị truyền thống, muốn ăn ngon mời khách
- **Pain:** ngại thực phẩm công nghiệp, muốn chuyện kể đi kèm sản phẩm
- **Tech:** Facebook, LinkedIn, ít TikTok
- **Behavior:** thích story dài có chiều sâu
- **Dealbreaker:** câu chuyện gượng ép / quảng cáo lộ liễu

### Persona C — Buyer siêu thị / AEON (cho NPD launch)
- **Tâm lý:** lý trí, đo bằng số, không cảm xúc
- **Pain:** hồ sơ thiếu giấy phép, P&L không khả thi, packaging sai NĐ 43
- **Tech:** Excel, email, Microsoft Word
- **Behavior:** quét nhanh, có sai sót pháp lý là từ chối
- **Dealbreaker:** sai NĐ 15/2018, sai NĐ 43/2017, sai NĐ 111/2021

### Persona D — NV xưởng NemThanh (cho app HTML internal)
- **Tâm lý:** quen tay, không thích phức tạp, muốn xong việc nhanh
- **Pain:** mạng yếu, iPhone đời cũ pin yếu, tay khô khó chạm chính xác
- **Tech:** chỉ iPhone Safari, không dùng Chrome, không cài app phức tạp
- **Behavior:** học bằng cách thử, không đọc hướng dẫn
- **Dealbreaker:** nút bấm nhỏ, app load chậm, lỗi không rõ

### Persona E — Khách TikTok 18-30 tuổi (cho content TikTok / Reels)
- **Tâm lý:** muốn giải trí + tò mò + mua nhanh
- **Pain:** chán quảng cáo dài, ghét tone "người lớn dạy đời"
- **Tech:** TikTok, Instagram, Shopee
- **Behavior:** lướt 3 giây/post, thích native content
- **Dealbreaker:** quay format cũ, voice-over đọc sách giáo khoa

---

## 🔍 Vai 2 — KHÁCH KHÓ TÍNH (×1.5 trọng số)

**Mô tả:** Người đa nghi, dễ bỏ ngang, hay phản biện gay gắt. Vai này quan trọng vì giúp Toàn chống bias confirmation (tự khen mình).

**Tâm lý:**
- Mặc định: "đây có lừa không?"
- Tìm điểm yếu trước, điểm mạnh sau
- Nghi ngờ mọi claim không có dẫn chứng
- Không tin marketing language
- Đã bị lừa nhiều lần, cảnh giác cao

**Pain points:**
- Quảng cáo quá lố
- Số liệu không nguồn
- Tone "vừa khoe vừa bán"
- Tự xưng "đặc sản", "truyền thống", "cao cấp" mà không chứng minh
- Câu mở chung chung (`"Bạn có biết..."`, `"Trong cuộc sống hiện đại..."`)

**Behavior:**
- Đọc kỹ câu mở, nếu không hook thì bỏ
- Soi từng câu xem có "fake hint" không
- Hỏi: "ai nói? lấy đâu ra số liệu này?"
- So sánh với đối thủ trong đầu

**Dealbreaker phổ biến:**
- Bịa số liệu / quote
- Không có call-to-action cụ thể
- Câu kết "Hy vọng bạn thích..." (sến)
- Lẫn lộn fact với opinion
- Sai chính tả, sai ngữ pháp

**Mẫu phản hồi của vai Khó tính:**
> "Câu mở quá quen thuộc, tôi đã đọc 100 lần. Đến đoạn 'thuần chủng' thì tôi nghi ngờ — có gì chứng minh? Số liệu '95% khách hàng hài lòng' lấy từ đâu? Bỏ giữa chừng."

---

## 🆕 Vai 3 — KHÁCH MỚI BIẾT (×1 trọng số)

**Mô tả:** Người chưa biết NemThanh / chưa biết Vịt Cổ Lũng / chưa biết Thanh Hóa. Đọc output này lần đầu, không có context.

**Tâm lý:**
- Tò mò nhưng không cam kết
- Hay bị overwhelmed nếu output có quá nhiều thuật ngữ
- Cần "context bridge" — giải thích ngắn gọn

**Pain points:**
- Thuật ngữ địa phương không giải thích (vd: "nem chua xứ Thanh", "Vịt Cổ Lũng" — không phải ai cũng biết Cổ Lũng là gì)
- Reference nội bộ không có chú thích
- Câu mở giả định người đọc đã biết

**Behavior:**
- Đọc tuần tự từ trên xuống
- Stop ngay khi gặp 1 câu khó hiểu
- Không google để tìm hiểu thêm — bỏ luôn

**Dealbreaker:**
- Mở bài giả định reader đã biết sản phẩm
- Dùng từ địa phương / từ nội bộ NemThanh không giải thích
- Acronym không spell-out lần đầu

**Mẫu phản hồi:**
> "Đọc đến 'Vịt Cổ Lũng' là tôi không biết đó là gì. Là giống vịt? Là tên làng? Tại sao đặc biệt? Tác giả giả định tôi đã biết — nhưng tôi không. Bỏ giữa chừng."

---

## 🧠 Vai 4 — KHÁCH SÀNH SỎI (×1 trọng số)

**Mô tả:** Đối thủ FMCG hoặc khách am hiểu thị trường nem chua / thực phẩm Việt. Đã thấy nhiều brand, nhiều bài viết, nhiều app. Đánh giá cao.

**Tâm lý:**
- "Cái này đã có ai làm chưa?"
- So sánh với benchmark trong đầu (Vissan, CP, Cầu Tre, Đức Việt...)
- Tìm angle độc đáo / pain point mới

**Pain points:**
- Nội dung copycat (clone bài đối thủ)
- Claim không khác biệt (mọi brand đều "thuần", "tươi", "không hóa chất")
- Stack công nghệ lạc hậu (vd: app HTML thay vì Flutter — nhưng đối với SME thì OK)
- Pricing không phù hợp scale

**Behavior:**
- Đọc kỹ, đối chiếu mental benchmark
- Tự test app/code, look for technical sophistication
- Hỏi: "có gì mới?"

**Dealbreaker:**
- Không có angle riêng
- Mượn lại positioning đối thủ
- Số liệu sai bối cảnh (vd: claim "thị phần 30%" nhưng SME không thể có)
- App có security flaw rõ ràng

**Mẫu phản hồi:**
> "Brand promise giống Cầu Tre 2018. Số 'thuần chủng 100%' — đối thủ Đức Việt cũng claim. Cần angle riêng. App code có XSS ở dòng 234 — đáng lo nếu deploy public."

---

## Quick mode — chỉ 2 vai

Khi chạy Quick mode, dùng 2 vai sau:
- **Vai Mục tiêu** (chọn persona phù hợp nhất theo output)
- **Vai Khó tính**

→ Bỏ Vai Mới biết và Vai Sành sỏi cho đỡ tốn token. Vẫn đủ catch điểm chết chính.

---

## Mẫu prompt roleplay cho Cách 1

```
Tôi đang đóng vai [Tên vai] — [mô tả 1 dòng].
Tâm lý: [3-4 từ khóa]
Pain points: [list]
Tech level: [Novice / Intermediate / Expert]
Behavior khi đọc output này: [mô tả ngắn]

Đọc output sau và phản hồi đúng theo tâm lý + pain của vai này:
[paste output]

Output dạng:
**Ấn tượng đầu (1-10):** [số] — [1 câu lý do]
**Điểm trừ chốt:** [cái khiến tôi bỏ ngang — quote chính xác]
**Điểm cộng nhất:** [cái tôi thích nhất]
**Top wish:** [cái nếu thêm/sửa thì pass]
**Rating tổng:** [1-10]
```
