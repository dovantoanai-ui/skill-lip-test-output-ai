# 6-cach-chi-tiet.md

Chi tiết từng cách trong 6 cách kiểm tra. Đọc lazy — chỉ load khi user yêu cầu áp dụng cách cụ thể, hoặc khi chạy Full mode.

---

## 🎭 Cách 1 — Đóng vai 4 khách

### Mục đích
Mô phỏng phản ứng từ 4 góc nhìn khác nhau, tổng hợp "điểm chết" (lỗi nào ≥ 2 vai cùng nêu = bắt fix).

### 4 vai dùng cho NemThanh
1. **Vai Mục tiêu** (×2 trọng số) — khách F&B đúng chân dung
2. **Vai Khó tính** (×1.5 trọng số) — khách đa nghi, dễ bỏ ngang
3. **Vai Mới biết** (×1) — chưa biết NemThanh, đọc lần đầu
4. **Vai Sành sỏi** (×1) — đối thủ FMCG hoặc khách am hiểu thị trường

Chi tiết từng vai xem `4-vai-khach-nemthanh.md`.

### Quy trình từng vai

```
Bước 1: Roleplay đúng vai (đọc kỹ tâm lý + pain points của vai đó)
Bước 2: Đọc output, ghi 4 điểm:
        • Ấn tượng đầu (1-10đ + 1 câu lý do)
        • Điểm trừ chốt (cái khiến vai này bỏ ngang ngay)
        • Điểm cộng nhất (cái khiến vai này thích nhất)
        • Top wish (cái nếu thêm/sửa sẽ pass)
Bước 3: Cho điểm tổng (1-10) + lý do
```

### Tổng hợp Weighted Vote

```
Điểm tổng = (Vai Mục tiêu × 2 + Vai Khó tính × 1.5 + Vai Mới × 1 + Vai Sành × 1) / 5.5

Điểm chết tự động:
- Lỗi ≥ 2 vai cùng nêu → vào Mục 2 báo cáo, mức "Cao"
- Lỗi ≥ 3 vai cùng nêu → mức "CHẶN"
```

### Quick mode
Chỉ chạy 2 vai: Mục tiêu + Khó tính. Tổng hợp đơn giản hơn.

---

## 📐 Cách 2 — Đo theo chuẩn ngành

### Mục đích
Đối chiếu output với 10 chuẩn cụ thể — pass/fail rõ ràng, không cảm tính.

### 10 chuẩn giữ lại (đã cắt từ 20 chuẩn gốc)

**Cho bài viết / content:**
1. **BLUF** — trọng điểm trong 2 câu đầu
2. **Hook** — câu mở tạo curiosity / nói được value
3. **Useful + Enjoyable + Inspired (CMI)** — 3 tiêu chí content

**Cho code:**
4. **Function ≤ 50 dòng** — không có hàm quá dài
5. **OWASP Top 10** — chỉ kiểm 3 lỗ hổng phổ biến nhất: XSS / Injection / Broken Auth
6. **Clean naming** — tên biến/hàm tự giải thích, không cần comment

**Cho app HTML / giao diện:**
7. **WCAG contrast ≥ 4.5:1** — tỷ lệ tương phản chữ/nền
8. **Mobile 375px** — mở được trên iPhone SE/đời cũ
9. **Touch target ≥ 44px** — nút bấm to (Fitts's Law)

**Cho giấy tờ:**
10. **Pyramid + MECE** — kết luận trước, giải thích sau; mục không trùng không sót

### Cách chấm

```
Mỗi chuẩn: PASS / FAIL / N/A
Score Cách 2 = (PASS / Áp dụng được) × 100
```

### Quick mode
Chỉ chạy 3 chuẩn quan trọng nhất theo loại:
- Bài viết: BLUF + Hook + CMI
- Code: Function ≤50 + OWASP + Clean naming
- App: Contrast + Mobile 375px + Touch ≥44px
- Giấy tờ: Pyramid + MECE + (1 chuẩn khác tùy nội dung)

---

## ✓ Cách 3 — Soát 17 quy tắc

### Mục đích
Bộ quy tắc cứng — pass/fail bằng quan sát trực tiếp, ít cảm tính nhất.

### 6 quy tắc CHUNG (apply mọi loại output)

| Mã | Quy tắc | Mức |
|----|---------|-----|
| QC-1 | Không bịa thông tin (mọi claim phải verifiable) | CHẶN |
| QC-2 | Không tự mâu thuẫn (đầu nói A, cuối phủ A) | CHẶN |
| QC-3 | Không để chỗ trống `[TODO]` `[TBD]` `[INSERT]` | Cao |
| QC-4 | Không nói chung chung "nhiều người cho rằng..." | Cao |
| QC-5 | Đúng phạm vi yêu cầu (không thiếu, không độn vô nghĩa) | Cao |
| QC-6 | Không có định kiến giới/tuổi/vùng miền | TB |

### 3 quy tắc BÀI VIẾT

| Mã | Quy tắc | Mức |
|----|---------|-----|
| BV-1 | Hook ≤ 3 câu, có móc câu rõ (curiosity / value / story) | Cao |
| BV-2 | Mỗi luận điểm có dẫn chứng (số liệu / ví dụ / trích lời) | Cao |
| BV-3 | CTA cụ thể — "click here" là FAIL, "tải mẫu ở X" là PASS | Cao |

### 4 quy tắc CODE (tất cả CHẶN — vì là rủi ro security)

| Mã | Quy tắc | Mức |
|----|---------|-----|
| CD-1 | KHÔNG hardcode mật khẩu / api_key / token | CHẶN |
| CD-2 | Mọi cuộc gọi API/file có try-catch | CHẶN |
| CD-3 | Validate dữ liệu nhập tại boundary (form/Excel/ảnh) | CHẶN |
| CD-4 | Chống XSS — không đẩy text user vào `innerHTML` | CHẶN |

### 2 quy tắc CODE phụ

| Mã | Quy tắc | Mức |
|----|---------|-----|
| CD-5 | Dọn dead code khi version bump (v6 → v10) | TB |
| CD-6 | Magic numbers (giá nem, quy đổi cái↔túi) phải đặt const | TB |

### 4 quy tắc GIAO DIỆN

| Mã | Quy tắc | Mức |
|----|---------|-----|
| GD-1 | Tương phản chữ/nền ≥ 4.5:1 | CHẶN |
| GD-2 | Touch target ≥ 44×44px | CHẶN |
| GD-3 | Có trạng thái rỗng (không màn trắng tinh) | Cao |
| GD-4 | Thông báo lỗi rõ — không "Error occurred" | Cao |

### 2 quy tắc GIẤY TỜ

| Mã | Quy tắc | Mức |
|----|---------|-----|
| GT-1 | Kết luận đặt đầu (Pyramid Principle) | Cao |
| GT-2 | Không section "TBD" / "đang cập nhật" | Cao |

### Cách chấm

```
Score Cách 3 = (PASS / Áp dụng được) × 100

Quick mode: chỉ chạy quy tắc CHẶN + Cao (bỏ TB)
```

---

## 👨‍🏫 Cách 4 — Mượn mắt 6 chuyên gia

### 6 chuyên gia giữ lại

**Bài viết:**
1. **David Ogilvy** — *"The consumer isn't a moron"*
   - Kiểm: cụ thể chưa? Có wordplay che mất message không?
   - Test: thay câu "clever" bằng câu plain — nếu mạnh hơn thì Ogilvy thích

2. **Ann Handley** — *"Useful + Inspired + Well-written"*
   - Kiểm: có utility rõ không? Có angle riêng không? Đọc được không?

**Code:**
3. **Robert C. Martin (Uncle Bob)** — *Clean Code: SRP, DRY, small functions*
   - Kiểm: mỗi hàm làm đúng 1 việc? Không duplicate logic? Tên có tự giải thích?

4. **Linus Torvalds** — *"Good taste = simple"*
   - Kiểm: có overengineering không? Có thể đơn giản hơn không?

**Giao diện:**
5. **Steve Jobs** — *"Simple is harder than complex"*
   - Kiểm: có element nào remove được mà không mất function không?

6. **Luke Wroblewski** — *"Mobile first"*
   - Kiểm: design có work trên mobile trước không? Touch-friendly không?

### Quick mode
Chỉ chọn 1 chuyên gia phù hợp nhất theo loại output. Mỗi chuyên gia output 3 dòng:
- They'd praise: [element + dẫn chứng]
- They'd critique: [issue + dẫn chứng]
- Their advice: [1 action cụ thể trong style của họ]

---

## 🤖 Cách 5 — 6 test tự động

### 6 test giữ lại

| # | Test | Cách chạy | Pass khi |
|---|------|-----------|----------|
| TĐ-1 | Đếm số từ | Đếm từ output | Trong khoảng đích (post: 100-300, blog: 600-2500) |
| TĐ-2 | Quét placeholder | regex `/\[TODO\]\|\[TBD\]\|\[INSERT\]\|Lorem ipsum/i` | Zero matches |
| TĐ-3 | Validate cú pháp code | Parse bằng `acorn` (Toàn đã có) | Zero syntax errors |
| TĐ-4 | ⭐ Quét mật khẩu/token | regex `/(password\|api_key\|secret\|token)\s*=\s*['"][^'"]+/i` | Zero matches |
| TĐ-5 | Đo tương phản | Tính luminance contrast của text/bg | ≥ 4.5:1 |
| TĐ-6 | Form có label | Mỗi `<input>` có `<label>` | 100% |

### Cách chạy
- Code thật (Bash + regex grep) — KHÔNG "chạy thủ công trong đầu"
- Mỗi test deterministic: PASS / FAIL / N/A

### Quick mode (smoke test)
Chỉ chạy TĐ-1 + TĐ-2 + TĐ-4 (3 test nhanh nhất, 30 giây).

---

## 📱 Cách 6 — Test thật trên iPhone

### Chỉ áp dụng khi output là APP HTML đã deploy / có URL preview.

### 6 kịch bản

```
┌─────────────────────────────────────────────────────────────┐
│ KB1 │ ẤN TƯỢNG 5 GIÂY                                       │
│     │ → Mở app fresh, đếm 5 giây                           │
│     │ → Hỏi: NV có hiểu app làm gì không?                  │
│     │ → Pass khi: purpose rõ trong 5 giây                  │
├─────┼───────────────────────────────────────────────────────┤
│ KB2 │ ĐI HẾT LUỒNG CHÍNH                                    │
│     │ → Ví dụ: nhập 1 đơn nem từ đầu đến cuối              │
│     │ → Note: friction, hành vi không mong đợi             │
│     │ → Pass khi: hoàn thành mục tiêu không bối rối        │
├─────┼───────────────────────────────────────────────────────┤
│ KB3 │ CLICK MỌI NÚT                                         │
│     │ → Bấm hết CTA, mở/đóng popup, dropdown               │
│     │ → Pass khi: không có nút lỗi 404 / freeze            │
├─────┼───────────────────────────────────────────────────────┤
│ KB4 │ TRẠNG THÁI LỖI                                        │
│     │ → Nhập rỗng / sai định dạng / URL không tồn tại      │
│     │ → Pass khi: thông báo lỗi rõ + có cách thoát         │
├─────┼───────────────────────────────────────────────────────┤
│ KB5 │ ⭐ MOBILE 375PX (iPhone SE)                           │
│     │ → Thu cửa sổ về 375px                                │
│     │ → Pass khi: đọc được, không scroll ngang, nút dễ chạm│
├─────┼───────────────────────────────────────────────────────┤
│ KB6 │ HIỆU NĂNG                                             │
│     │ → Đo thời gian load đến content có nghĩa             │
│     │ → Pass khi: ≤ 2 giây, không layout shift             │
└─────┴───────────────────────────────────────────────────────┘
```

### Mẫu nhật ký test

```
KB[N]: [Tên kịch bản]
URL test: [link]
Thiết bị: iPhone [model] / Safari
Bước thực hiện: [làm gì]
Kết quả: ✅ PASS / ❌ FAIL / ⚠️ ISSUE
Mức độ: CHẶN / Cao / TB / Thấp
Chi tiết issue (nếu có): [mô tả + screenshot path]
```

### Cách chạy
- **Toàn dùng iPhone thật** (không browser tool tự động)
- Mỗi kịch bản 1-2 phút
- Tổng Quick mode: chỉ KB1 + KB5 (~3 phút)
- Tổng Full mode: cả 6 kịch bản (~10 phút)

---

## Bảng cân điểm tổng (sau khi chạy 6 cách)

```
Score tổng = trung bình các cách đã chạy (chỉ tính cách áp dụng)

Áp Quy tắc Chặn Nghiệm Thu:
  - Có lỗi NẶNG     →  cap 69 (3 mức: ✅ Pass / ⚠️ Cần sửa / ❌ Không giao)
  - Có 3 lỗi VỪA    →  cap 79
  - Không có gì     →  điểm thực

Diễn giải:
  ≥ 80   ✅ Pass — có thể giao
  60-79  ⚠️ Cần sửa — fix hết Cao trước khi giao
  < 60   ❌ Không giao — rework
```
