# Cài đặt lib-test-output-ai

Skill kiểm tra chất lượng output AI tạo ra (bài viết / code / app HTML / giấy tờ) cho NemThanh — phiên bản rút gọn 50% từ `vibe-review` gốc.

## Vị trí trong hệ thống

```
[lib-CORE] lib-test-output-ai
├── Loại     : Copy/library (conservative trigger)
├── Domain   : CORE (meta-skill, không thuộc MKT/OPS/COMP/NPD)
├── Trigger  : Chỉ khi user gọi đích danh "test-output-ai"
│              hoặc nói rõ "kiểm chất lượng output", "QC bài viết/code/app"
└── Token    : ~10K mỗi lần Quick mode (giảm 50% so với vibe-review gốc)
```

## Đường dẫn cài đặt

### Hệ thống Siêu dự án (Toàn — máy local)

```bash
# Copy skill vào folder Skills của Siêu dự án
E:\Skills\lib-test-output-ai\
├── SKILL.md
├── references\
│   ├── 6-cach-chi-tiet.md
│   └── 4-vai-khach-nemthanh.md
└── INSTALL.md (file này)
```

### Claude Desktop / Claude Code

```bash
# Personal (mọi project)
~/.claude/skills/lib-test-output-ai/

# Hoặc project-only
.claude/skills/lib-test-output-ai/
```

## Cách gọi skill

Vì là conservative trigger (lib-), skill **KHÔNG tự động chạy**. Toàn phải gọi đích danh:

```
"Dùng test-output-ai cho bài viết Vịt Cổ Lũng tháng 5"
"Test output AI: [paste output]"
"Kiểm chất lượng output này theo 6 cách"
"QC bài viết / app / code này trước khi giao"
"Chạy lib-test-output-ai cho [output]"
```

### Mode chạy

| Mode | Cách invoke | Thời gian | Token |
|------|-------------|-----------|-------|
| **Quick** (mặc định) | `test-output-ai [output]` | ~5 phút | ~10K |
| **Single 1 cách** | `test-output-ai [output] --cach 3` | ~3 phút | ~5K |
| **Full đầy đủ** | `test-output-ai [output] --full` | ~15-20 phút | ~25K |

## Tích hợp với 6 skill anh em

```
Workflow điển hình:

[Tạo output] ──▶ thuong-hieu-content (cho content)
                  html-business-app (cho app)
                  product-launch (cho NPD)
                  dashboard-ggsheet (cho dashboard)
                          │
                          ▼
[Kiểm chất lượng] ──▶ lib-test-output-ai
                          │
                          ├─ Pass     ──▶ Giao
                          ├─ Cần sửa  ──▶ Quay lại skill creation, fix
                          └─ Không giao ──▶ Rework
```

## Yêu cầu công cụ

- **Cách 5 (Tự động):** Cần Bash tool — đã có sẵn trong Claude Desktop / Claude Code
- **Cách 6 (Test mobile):** Toàn dùng iPhone thật, không cần browser MCP tool

Skill vẫn chạy được nếu thiếu công cụ — chỉ skip cách tương ứng.

## Gỡ cài đặt

```bash
rm -rf E:\Skills\lib-test-output-ai\
# hoặc
rm -rf ~/.claude/skills/lib-test-output-ai/
```

## Phiên bản

- **v0.1.0** (05/2026) — bản đầu, scale-down 50% từ `vibe-review` gốc
  - Giữ 56/110 tính năng
  - Cắt benchmark phương Tây không apply tiếng Việt
  - Cắt 9/15 chuyên gia (giữ Ogilvy, Handley, Uncle Bob, Linus, Steve Jobs, Luke W)
  - Cắt 14/20 test tự động không apply NemThanh
  - Cắt mode Full mặc định, chỉ Quick + Single
  - Lift 5 persona Vịt Cổ Lũng từ `thuong-hieu-content` (không duplicate)

## Roadmap tiếp theo (cân nhắc)

- v0.2.0: thêm reference riêng cho audit pháp lý F&B (NĐ 15/2018, NĐ 43/2017) — chỉ kích hoạt khi loại output là "giấy tờ NPD"
- v0.3.0: tích hợp mẫu nhật ký test mobile vào file riêng có thể export PDF
